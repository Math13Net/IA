const target = document.getElementById("target");
const scoreDisplay = document.getElementById("score");
const timerBar = document.getElementById("timer-bar");
const gameArea = document.getElementById("game");
const endScreen = document.getElementById("end-screen");
const finalScoreDisplay = document.getElementById("final-score");
const clickSound = document.getElementById("click-sound");
const endSound = document.getElementById("end-sound");

let score = 0;
let timeLeft = 300; // secondes
let gameActive = true;
let timerInterval;

// Génère une position aléatoire
function randomPosition() {
  const gameWidth = window.innerWidth - target.offsetWidth;
  const gameHeight = window.innerHeight - target.offsetHeight;
  const x = Math.random() * gameWidth;
  const y = Math.random() * gameHeight;
  target.style.left = `${x}px`;
  target.style.top = `${y}px`;
}

// Met à jour le score
function updateScore() {
  if (!gameActive) return;
  score++;
  scoreDisplay.textContent = `Score: ${score}`;
  randomPosition();
  shrinkTarget();
  clickSound.currentTime = 0;
  clickSound.play();
}

// Réduit la taille du cercle
function shrinkTarget() {
  if (score % 10 === 0 && target.offsetWidth > 20) {
    const newSize = target.offsetWidth - 2;
    target.style.width = `${newSize}px`;
    target.style.height = `${newSize}px`;
  }
}

// Met à jour le timer
function updateTimer() {
  if (timeLeft <= 0) {
    endGame();
  } else {
    timeLeft--;
    updateTimerBar();
  }
}

// Met à jour la barre de progression
function updateTimerBar() {
  const pourcentage = (timeLeft / 300) * 100;
  timerBar.style.width = `${pourcentage}%`;
}

// Termine le jeu
function endGame() {
  clearInterval(timerInterval);
  gameActive = false;
  target.style.display = "none";
  endSound.play();
  finalScoreDisplay.textContent = `Ton score final est : ${score}`;
  endScreen.classList.add("show");
}

// Relance le jeu
function restartGame() {
  score = 0;
  timeLeft = 300;
  gameActive = true;
  target.style.width = "60px";
  target.style.height = "60px";
  scoreDisplay.textContent = "Score: 0";
  target.style.display = "block";
  endScreen.classList.remove("show");
  randomPosition();
  updateTimerBar();
  clearInterval(timerInterval);
  timerInterval = setInterval(updateTimer, 1000);
}

function startGame() {
  randomPosition();
  target.addEventListener("click", updateScore);
  updateTimerBar();
  timerInterval = setInterval(updateTimer, 1000);
}

startGame();
