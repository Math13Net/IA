const notes = ['C', 'G', 'D', 'A', 'E', 'B', 'F#', 'C#', 'G#', 'D#', 'A#', 'F'];
const minorRelatives = {
  'C': 'A', 'G': 'E', 'D': 'B', 'A': 'F#', 'E': 'C#',
  'B': 'G#', 'F#': 'D#', 'C#': 'A#', 'G#': 'F', 'D#': 'C', 'A#': 'G', 'F': 'D'
};


const svg = document.getElementById('circle');
const centerX = 250;
const centerY = 250;
const radius = 200;
let noteElements = {};


notes.forEach((note, index) => {
  const angle = (index / notes.length) * 2 * Math.PI - Math.PI / 2;
  const x = centerX + radius * Math.cos(angle);
  const y = centerY + radius * Math.sin(angle);


  const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
  text.setAttribute('x', x);
  text.setAttribute('y', y);
  text.setAttribute('text-anchor', 'middle');
  text.setAttribute('dominant-baseline', 'middle');
  text.setAttribute('font-size', '22');
  text.setAttribute('fill', '#fff');
  text.setAttribute('cursor', 'pointer');
  text.textContent = note;


  text.addEventListener('click', () => highlightNotes(note));


  svg.appendChild(text);
  noteElements[note] = text;
});


function highlightNotes(selectedNote) {
  // Reset toutes les couleurs
  Object.values(noteElements).forEach(el => {
    el.classList.remove('selected', 'neighbor', 'relative-minor');
  });


  // Applique la couleur sur la note cliquée
  noteElements[selectedNote].classList.add('selected');


  // Quintes voisines
  const index = notes.indexOf(selectedNote);
  const prev = notes[(index - 1 + notes.length) % notes.length];
  const next = notes[(index + 1) % notes.length];
  noteElements[prev].classList.add('neighbor');
  noteElements[next].classList.add('neighbor');


  // Relative mineure
  const relativeMinor = minorRelatives[selectedNote];
  if (noteElements[relativeMinor]) {
    noteElements[relativeMinor].classList.add('relative-minor');
  }


  // Affiche dans le texte en bas
  document.getElementById('note-display').textContent =
    `Note sélectionnée : ${selectedNote} | Quintes voisines : ${prev}, ${next} | Relative mineure : ${relativeMinor}`;
}
